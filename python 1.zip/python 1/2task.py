#
# Петя, Катя и Сережа делают из бумаги журавликов. Вместе они сделали S журавликов.
# Сколько журавликов сделал каждый ребенок, если известно,
# что Петя и Сережа сделали одинаковое количество журавликов,
# а Катя сделала в два раза больше журавликов, чем Петя и Сережа вместе?
# Пример:
# 6 -> 1  4  1
# 24 -> 4  16  4
# 60 -> 10  40  10

S = int(input('How many total birds was made?: '))

# Seryoja = Petya
# Katya = 2 * (Seryoja + Petya)
# S = (Katya + Seryoja + Petya)
# S = ((2 * (Petya + Petya) + Petya + Petya)
# S = ( 4 * Petya + 2 * Petya)
# S = ( 6 * Petya)
# Petya = S/6

Petya = round(S / 6)
Seryoja = int(Petya)
Katya = 2 * (Petya + Seryoja)

print('Katya:', Katya)
print('Seryoja:', Seryoja)
print('Petya:', Petya)
