
# Требуется определить, можно ли от шоколадки размером n × m долек отломить k долек,
# если разрешается сделать один разлом по прямой между дольками
# (то есть разломить шоколадку на два прямоугольника).
# Пример:
# 3 2 4 -> yes
# 3 2 1 -> no

n = int(input('Length of the chocolate bar: '))
m = int(input('Height of the chocolate bar: '))
k = int(input('How many slices?: '))

s = n * m
if s == k:
    print('yes it\'s possible')
else: print('No it\'s immpossible')
